package com.dal.onlineappt.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dal.onlineappt.entity.Speciality;

@Repository
public interface SpecialityRepository extends CrudRepository<Speciality, Long>{

}
