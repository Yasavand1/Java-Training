package com.dal.onlineappt.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "patient")

public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long patientId;
	
	@Column(nullable = false,unique = false)
	public String patientName;
	
	@Column(nullable = false,unique = false)
	public String gender;
	
	@Column(nullable = false,unique = false)
	public Date dateofbirth;
	
	@Column(nullable = false,unique = true)
	public String mobileno;
	
	@Column(nullable = false,unique = true)
	public String mailid;
	
	@Column(nullable = false,unique = false)
	public Date createdDate;
	
    public Long getpatientId() {
		return patientId;
	}

	public void setpatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getpatientName() {
		return patientName;
	}

	public void setpatientName(String patientName) {
		this.patientName = patientName;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	
	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	
	public Date getcreateddate() {
		return createdDate;
	}

	public void setcreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	


	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Patient(Long patientId, String patientName, String gender, Date dateofbirth, String mobileno, String mailid, Date createdDate ) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.gender = gender;
		this.dateofbirth = dateofbirth;
		this.mobileno = mobileno;
		this.mailid = mailid;
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", gender="
				+ gender + ", dateofbirth=" + dateofbirth + ", mobileno=" + mobileno + ", mailid=" + mailid +", createdDate=" + createdDate +"]";
	}
	
	
}
