package com.dal.onlineappt.service;

import java.util.List;
import com.dal.onlineappt.entity.Slot;



public interface SlotService {
	
    public List<Slot> searchByDoctorIdAndSlotDate(String doctorId, String slotDate, String slotAvailability);
    
    
   
}
