package com.dal.onlineappt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dal.onlineappt.entity.Appointment;
import com.dal.onlineappt.entity.Patient;
import com.dal.onlineappt.entity.Slot;
import com.dal.onlineappt.repo.AppointmentRepository;
import com.dal.onlineappt.repo.SlotRepository;

import jakarta.persistence.EntityNotFoundException;




@Service
public class AppointmentServiceImpl implements AppointmentService{
	
	@Autowired
	AppointmentRepository appointmentrepository;
	
	@Autowired
	SlotRepository slotrepository;

	@Override
	public Appointment addAppointment(Appointment appointment) {
		return appointmentrepository.save(appointment);
	}
	
	@Override
	public List<Appointment> searchByPatientId(String PatientId) {
		return (List<Appointment>) appointmentrepository.findByPatientId(PatientId);
	}
	
	@Override
	public Appointment updateAppointment(Appointment appointment) {
		Appointment appt = appointmentrepository.findById(appointment.getAppointmentId()).orElse(null);
		appt.setStatus(appointment.getStatus());
		return appointmentrepository.save(appt);
	}
	

	@Override
	public Optional<Appointment> searchByAppointmentId(Long aid) {
		return appointmentrepository.findById(aid);
	}


}
