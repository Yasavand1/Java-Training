package com.dal.onlineappt.service;

import java.util.List;

import com.dal.onlineappt.entity.Speciality;


public interface SpecialityService {
	
	public List<Speciality> listAllSpeciality();

}
