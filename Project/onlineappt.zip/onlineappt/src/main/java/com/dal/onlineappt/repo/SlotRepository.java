package com.dal.onlineappt.repo;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dal.onlineappt.entity.Slot;


@Repository
public interface SlotRepository extends CrudRepository<Slot, String> {
	public List <Slot> findAvailableSlotsByDoctorIdAndSlotDateAndSlotAvailability(String doctorId, String slotDate, String slotAvailability);

}
