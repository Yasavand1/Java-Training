package com.dal.onlineappt.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.dal.onlineappt.entity.Appointment;



public interface AppointmentRepository extends CrudRepository<Appointment, Long>{
	public List <Appointment> findByPatientId(String PatientId);
	public Appointment findByAppointmentId(Long ApptId);

}
