package com.dal.onlineappt.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dal.onlineappt.entity.Patient;
import com.dal.onlineappt.repo.PatientRepository;
import com.dal.onlineappt.service.PatientService;

@RestController
public class PatientRestController {
	
	@Autowired
	PatientService patientservice;
	
	@Autowired
	PatientRepository patientrepository;
	
	@PostMapping("/PostPatient")	
	public Patient addPatient(@RequestBody Patient patient){
		return patientservice.addPatient(patient);
	}
	
	@GetMapping("/GetPatientByMobileno/{mobileno}")
	public Patient searchBymobileno(@PathVariable String mobileno) {
		return patientservice.searchBymobileno(mobileno);
	}
	
	@GetMapping("/GetPatientByMailId/{mailid}")
	public Patient searchBymailid(@PathVariable String mailid) {
		return patientservice.searchBymailid(mailid);
	}
	
	
	@DeleteMapping("/DeletePatient/{pid}")  
	public void deletePatient(@PathVariable("pid") String pid){   
		patientservice.deleteById(pid);  
	} 
	
	@GetMapping("/ListPatients")
    public List<Patient> listAllPatients() {
    return patientservice.listAllPatients();
    }

}
