package com.dal.onlineappt.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name ="specialitymaster")

public class Speciality {
	
	@Id
	@Column(nullable = false,unique = true)
	private String sno;

	@Column(nullable = false,unique = false)
	private String specialityCode;
	
	@Column(nullable = false,unique = false)
	private String specialityName;

	public Speciality() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Speciality(String specialityCode, String specialityName) {
		super();
		this.specialityCode = specialityCode;
		this.specialityName = specialityName;
	}

	@Override
	public String toString() {
		return "Speciality [specialityCode=" + specialityCode + ", specialityName=" + specialityName + "]";
	}

	public String getSpecialityCode() {
		return specialityCode;
	}

	public void setSpecialityCode(String specialityCode) {
		this.specialityCode = specialityCode;
	}

	public String getSpecialityName() {
		return specialityName;
	}

	public void setSpecialityName(String specialityName) {
		this.specialityName = specialityName;
	}
	
	
}
