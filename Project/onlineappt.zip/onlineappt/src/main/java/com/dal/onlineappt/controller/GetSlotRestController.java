package com.dal.onlineappt.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dal.onlineappt.entity.Slot;
import com.dal.onlineappt.service.SlotService;




@RestController
public class GetSlotRestController {
	
	@Autowired
	SlotService slotservice;

	
	@GetMapping("/GetSlots")
	public List<Slot> searchByDoctorIdAndSlotDate(@RequestParam(value = "doctorId", required = true) String doctorId, @RequestParam(value = "slotDate", required = true) String slotDate, @RequestParam(value = "slotAvailability", required = true) String slotAvailability) {
		return slotservice.searchByDoctorIdAndSlotDate(doctorId, slotDate, slotAvailability);
	}
	

}