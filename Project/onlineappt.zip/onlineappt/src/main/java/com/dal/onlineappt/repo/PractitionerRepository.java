package com.dal.onlineappt.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.dal.onlineappt.entity.Practitioner;


@Repository
public interface PractitionerRepository extends CrudRepository<Practitioner, String>{
	public List<Practitioner> findByspecialityCode(String specialityCode);

}
