package com.dal.onlineappt.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity(debug = true)
public class ApptSecurityConfig {
	
	@Autowired
	ApptAuthProvider apptAuthProvider;
	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	http.authorizeHttpRequests().requestMatchers("/welcome/**").permitAll()
	.requestMatchers("/v2/api-docs",
			"/v3/api-docs/**",
			"/swagger-resources/configuration/ui",  
			"/swagger-resources/configuration/security", 
			"/webjars/**",
			"/swagger-ui.html","/swagger-ui/**").permitAll()
	.requestMatchers("/GetPatientByMobileno/**").permitAll()
	.requestMatchers("/GetPatientByMailId/**").permitAll()
	.requestMatchers("/ListPatients/**").authenticated()
	.requestMatchers("/PostPatient/**").permitAll()
	.requestMatchers("/DeletePatient/**").authenticated()
	.requestMatchers("/ListSpeciality/**").permitAll()
	.requestMatchers("/FindPractitionersBySpecialityCode/**").permitAll()
	.requestMatchers("/GetSlots/**").authenticated()
    .requestMatchers("/CreateAppointment").authenticated()
    .requestMatchers("/CancelAppointment").authenticated()
    .requestMatchers("/findbyappointmentid/**").authenticated()
	.requestMatchers("/GetAppointmentsByPatientId/**").authenticated();
	http.httpBasic();
	http.cors();
	http.csrf().disable(); 
	return http.build();
    }
	
	@Bean
	public AuthenticationManager authManager(HttpSecurity http) throws Exception {

		AuthenticationManagerBuilder authenticationManagerBuilder = http
				.getSharedObject(AuthenticationManagerBuilder.class);
		authenticationManagerBuilder.authenticationProvider(apptAuthProvider);
		return authenticationManagerBuilder.build();
	}
	

}
