package com.dal.onlineappt.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.dal.onlineappt.entity.Appointment;
import com.dal.onlineappt.entity.Patient;
import com.dal.onlineappt.repo.AppointmentRepository;
import com.dal.onlineappt.repo.PatientRepository;
import com.dal.onlineappt.service.AppointmentService;
import org.springframework.web.bind.annotation.PutMapping;





@RestController
public class AppointmentRestController {
	
	@Autowired
	AppointmentService appointmentservice;
	
	@Autowired
	AppointmentRepository appointmentrepository;
	
	@Autowired
	PatientRepository patientrepository;
	
	
	@PostMapping("/CreateAppointment")	
	public Appointment addAppointment(@RequestBody Appointment appointment) throws Exception {
		return appointmentservice.addAppointment(appointment);
	}
	
	@GetMapping("/GetAppointmentsByPatientId/{PatientId}")
	public List<Appointment> searchPatientId(@PathVariable String PatientId) {
		return appointmentservice.searchByPatientId(PatientId);
	}
	
	@GetMapping("/findbyappointmentid/{aid}")
	public Optional<Appointment> searchByAppointmentId(Long aid) {
		return appointmentservice.searchByAppointmentId(aid);
	}
	
	@PutMapping("/CancelAppointment")
	public Appointment updateAppointment(@RequestBody Appointment appointment) {
		return appointmentservice.updateAppointment(appointment);
	}
	

	
	
	

}
