package com.dal.onlineappt.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "appointment")

public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long appointmentId;
	
	@Column(nullable = false,unique = false)
	private String patientId;
	
	@Column(nullable = false,unique = false)
	private String doctorId;
	
	@Column(nullable = false,unique = false)
	private String slotId;
	
	@Column(nullable = false,unique = false)
	private String status;
	
	@Column(nullable = false,unique = false)
	private String createdDate;
	
	@Column(nullable = true,unique = false)
	private String UpdatedDate;
	
	@Column(nullable = false,unique = false)
	private String apptStartTime;
	
	@Column(nullable = false,unique = false)
	private String apptEndTime;
	
	@Column(nullable = false,unique = false)
	private String apptDate;

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Appointment(Long appointmentId, String patientId, String doctorId, String slotId, String status,
			String createdDate, String updatedDate, String apptStartTime, String apptEndTime, String apptDate) {
		super();
		this.appointmentId = appointmentId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.slotId = slotId;
		this.status = status;
		this.createdDate = createdDate;
		this.UpdatedDate = updatedDate;
		this.apptStartTime = apptStartTime;
		this.apptEndTime = apptEndTime;
		this.apptDate = apptDate;
	}

	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", patientId=" + patientId + ", doctorId=" + doctorId
				+ ", slotId=" + slotId + ", status=" + status + ", createdDate=" + createdDate + ", UpdatedDate="
				+ UpdatedDate + ", apptStartTime=" + apptStartTime + ", apptEndTime=" + apptEndTime + ", apptDate="
				+ apptDate + "]";
	}

	public Long getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public String getSlotId() {
		return slotId;
	}

	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedDate() {
		return UpdatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		UpdatedDate = updatedDate;
	}

	public String getApptStartTime() {
		return apptStartTime;
	}

	public void setApptStartTime(String apptStartTime) {
		this.apptStartTime = apptStartTime;
	}

	public String getApptEndTime() {
		return apptEndTime;
	}

	public void setApptEndTime(String apptEndTime) {
		this.apptEndTime = apptEndTime;
	}

	public String getApptDate() {
		return apptDate;
	}

	public void setApptDate(String apptDate) {
		this.apptDate = apptDate;
	}
	
	
}
