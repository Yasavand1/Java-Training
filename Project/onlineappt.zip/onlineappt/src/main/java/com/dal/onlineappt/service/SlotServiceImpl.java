package com.dal.onlineappt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dal.onlineappt.entity.Slot;
import com.dal.onlineappt.repo.SlotRepository;





@Service
public class SlotServiceImpl implements SlotService{
	
	@Autowired
	SlotRepository slotrepository;
	
	@Override
	public List<Slot> searchByDoctorIdAndSlotDate(String doctorId, String slotDate, String slotAvailability) {
		// TODO Auto-generated method stub
		return (List<Slot>)slotrepository.findAvailableSlotsByDoctorIdAndSlotDateAndSlotAvailability(doctorId, slotDate, slotAvailability);
	}

}
