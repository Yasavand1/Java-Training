package com.dal.onlineappt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dal.onlineappt.entity.Speciality;
import com.dal.onlineappt.service.SpecialityService;

@RestController
public class SpecialityRestController {
	
	@Autowired
	SpecialityService specialityservice;

	@GetMapping("/ListSpeciality")
	public List<Speciality> listAllSpeciality() {
    return specialityservice.listAllSpeciality();
	}
}
