package com.dal.onlineappt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dal.onlineappt.entity.Patient;
import com.dal.onlineappt.repo.PatientRepository;




@Service
public class PatientServiceImpl implements PatientService{
	
	@Autowired
	PatientRepository patientrepository;

	@Override
	public Patient addPatient(Patient patient) {
		return patientrepository.save(patient);
	}
	
	@Override
	public Patient searchBymobileno(String mobileno) {
		return patientrepository.findBymobileno(mobileno);
	}
	
	@Override
	public Patient searchBymailid(String mailid) {
		return patientrepository.findBymailid(mailid);
	}
	
	
	@Override
	public void deleteById(String pid) {
	patientrepository.deleteById(pid); 
		
	} 
	
	@Override
    public List<Patient> listAllPatients() {
    return (List<Patient>) patientrepository.findAll();
    }

}
