package com.dal.onlineappt.service;


import java.util.List;
import java.util.Optional;

import com.dal.onlineappt.entity.Appointment;




public interface AppointmentService {
	public Appointment addAppointment(Appointment appointment);
	public List<Appointment> searchByPatientId(String PatientId);
	public Appointment updateAppointment(Appointment appointment);
	public Optional <Appointment> searchByAppointmentId(Long aid);
	

}

