package com.dal.onlineappt.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dal.onlineappt.entity.Patient;




@Repository
public interface PatientRepository extends CrudRepository<Patient, String>{
	public Patient findBymobileno(String mobileno);
	public Patient findBymailid(String mailid);
	public Patient deleteBypatientId(String pid);

}
