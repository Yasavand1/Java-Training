package com.dal.onlineappt.config;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.dal.onlineappt.entity.Patient;
import com.dal.onlineappt.repo.PatientRepository;



@Component
public class ApptAuthProvider implements AuthenticationProvider {
	
	@Autowired
	PatientRepository patientrepository;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String username = authentication.getName();
		String pwd = authentication.getCredentials().toString();
		Patient patient = patientrepository.findBymailid(username);
		System.out.println("Found Patient object" + patient);
		if (patient == null) {
			throw new StackOverflowError("No user got registered");
		} else if (pwd.equals(patient.getMobileno())) {
			return new UsernamePasswordAuthenticationToken(username, pwd, null);
		} else {
			System.out.println("I am a bad credentails");
			throw new StackOverflowError("Invalid Password");
		}
	}

	@Override
	public boolean supports(Class<?> authentication) {

		return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
	}

}
