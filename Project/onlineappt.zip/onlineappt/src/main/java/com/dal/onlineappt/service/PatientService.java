package com.dal.onlineappt.service;

import java.util.List;
import java.util.Optional;

import com.dal.onlineappt.entity.Patient;



public interface PatientService {
	public Patient addPatient(Patient patient);
	public Patient searchBymobileno(String mobileno);
	public Patient searchBymailid(String mailid);
	public void deleteById(String pid);
	public List<Patient> listAllPatients();

}
