package com.dal.onlineappt.service;

import java.util.List;

import com.dal.onlineappt.entity.Practitioner;

public interface PractitionerService {
	public List<Practitioner> searchByspecialityCode(String specialityCode);

}
