package com.dal.onlineappt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.dal.onlineappt.entity.Practitioner;
import com.dal.onlineappt.service.PractitionerService;

@RestController
public class PractitionerRestController {
	
	@Autowired
	PractitionerService practitionerservice;
	
	@GetMapping("/FindPractitionersBySpecialityCode/{specialityCode}")
	public List<Practitioner> searchByspecialityCode(@PathVariable String specialityCode){
		return practitionerservice.searchByspecialityCode(specialityCode);
	}

}
