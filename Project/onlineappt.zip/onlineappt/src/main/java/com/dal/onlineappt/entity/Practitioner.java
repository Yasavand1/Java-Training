package com.dal.onlineappt.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name ="practitioner")
public class Practitioner {
	
	@Id
	@Column(nullable = false,unique = true)
	private String practitionerId;

	@Column(nullable = false,unique = false)
	private String practitionerName;
	
	@Column(nullable = false,unique = false)
	private String specialityCode;
	
	@Column(nullable = false,unique = false)
	private String yearsofexperience;
	
	@Column(nullable = false,unique = false)
	private String registrationNumber;
	
	@Column(nullable = false,unique = false)
	private String qualification;
	
	@Column(nullable = false,unique = false)
	private String languagesknown;
	
	@Column(nullable = false,unique = false)
	private String consultationFees;
	
	@Column(nullable = false,unique = false)
	private String consultationTimings;
	
	@Column(nullable = false,unique = false)
	private String status;

	public Practitioner() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Practitioner(String practitionerId, String practitionerName, String specialityCode, String yearsofexperience,
			String registrationNumber, String qualification, String languagesknown, String consultationFees,
			String consultationTimings, String status) {
		super();
		this.practitionerId = practitionerId;
		this.practitionerName = practitionerName;
		this.specialityCode = specialityCode;
		this.yearsofexperience = yearsofexperience;
		this.registrationNumber = registrationNumber;
		this.qualification = qualification;
		this.languagesknown = languagesknown;
		this.consultationFees = consultationFees;
		this.consultationTimings = consultationTimings;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Practitioner [practitionerId=" + practitionerId + ", practitionerName=" + practitionerName
				+ ", specialityCode=" + specialityCode + ", yearsofexperience=" + yearsofexperience
				+ ", registrationNumber=" + registrationNumber + ", qualification=" + qualification
				+ ", languagesknown=" + languagesknown + ", consultationFees=" + consultationFees
				+ ", consultationTimings=" + consultationTimings + ", status=" + status +"]";
	}

	public String getPractitionerId() {
		return practitionerId;
	}

	public void setPractitionerId(String practitionerId) {
		this.practitionerId = practitionerId;
	}

	public String getPractitionerName() {
		return practitionerName;
	}

	public void setPractitionerName(String practitionerName) {
		this.practitionerName = practitionerName;
	}

	public String getSpecialityCode() {
		return specialityCode;
	}

	public void setSpecialityCode(String specialityCode) {
		this.specialityCode = specialityCode;
	}

	public String getYearsofexperience() {
		return yearsofexperience;
	}

	public void setYearsofexperience(String yearsofexperience) {
		this.yearsofexperience = yearsofexperience;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getLanguagesknown() {
		return languagesknown;
	}

	public void setLanguagesknown(String languagesknown) {
		this.languagesknown = languagesknown;
	}

	public String getConsultationFees() {
		return consultationFees;
	}

	public void setConsultationFees(String consultationFees) {
		this.consultationFees = consultationFees;
	}

	public String getConsultationTimings() {
		return consultationTimings;
	}

	public void setConsultationTimings(String consultationTimings) {
		this.consultationTimings = consultationTimings;
	}
	
	public String status() {
		return status;
	}

	public void setstatus(String status) {
		this.status = status;
	}



	
}
