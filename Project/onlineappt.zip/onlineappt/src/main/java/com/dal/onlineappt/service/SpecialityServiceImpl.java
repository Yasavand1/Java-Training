package com.dal.onlineappt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dal.onlineappt.entity.Speciality;
import com.dal.onlineappt.repo.SpecialityRepository;


@Service
public class SpecialityServiceImpl implements SpecialityService{
	
	@Autowired
	SpecialityRepository specialityRepository;
	
	@Override
	public List<Speciality> listAllSpeciality() {
     return (List<Speciality>) specialityRepository.findAll();
	}
	

}
