package com.dal.onlineappt.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "practitionerslots")
public class Slot {

	     @Id
	    //@GeneratedValue(strategy = GenerationType.AUTO)
	    private Integer slotId;
		
	    @Column(nullable = false, unique = false)
	    private String slotDate;
	
	    
	    @Column(nullable = false, unique = false)
		private String doctorId;
		
		@Column(nullable = false, unique = false)
		private String slotstarttime;
		
		@Column(nullable = false, unique = false)
		private String slotendtime;
		
		@Column(nullable = false, unique = false)
	    private String slotAvailability;

		public Slot() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Slot(Integer slotId, String slotDate, String doctorId, String slotstarttime, String slotendtime,
				String slotAvailability) {
			super();
			this.slotId = slotId;
			this.slotDate = slotDate;
			this.doctorId = doctorId;
			this.slotstarttime = slotstarttime;
			this.slotendtime = slotendtime;
			this.slotAvailability = slotAvailability;
		}

		@Override
		public String toString() {
			return "Slot [slotid=" + slotId + ", SlotDate=" + slotDate + ", DoctorId=" + doctorId + ", slotstarttime="
					+ slotstarttime + ", slotendtime=" + slotendtime + ", slotavailability=" + slotAvailability + "]";
		}

		public Integer getSlotid() {
			return slotId;
		}

		public void setSlotId(Integer slotId) {
			this.slotId = slotId;
		}

		public String getslotDate() {
			return slotDate;
		}

		public void setslotdate(String slotDate) {
			this.slotDate = slotDate;
		}

		public String getdoctorId() {
			return doctorId;
		}

		public void setdoctorid(String doctorId) {
			this.doctorId = doctorId;
		}

		public String getslotstarttime() {
			return slotstarttime;
		}

		public void setslotstarttime(String slotstarttime) {
			this.slotstarttime = slotstarttime;
		}

		public String getslotendtime() {
			return slotendtime;
		}

		public void setslotendtime(String slotendtime) {
			this.slotendtime = slotendtime;
		}

		public String getslotAvailability() {
			return slotAvailability;
		}

		public void setslotAvailability(String slotAvailability) {
			this.slotAvailability = slotAvailability;
		}
		
		
		
	}



