package com.dal.onlineappt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class onlineapptapplication {
	
	public static void main(String[] args) {
		SpringApplication.run(onlineapptapplication.class, args);
	}

}
