package com.dal.onlineappt;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
public class SpecialityTest {
	
	@Autowired
     private MockMvc mockMvc;

	@Test
	public void SpecialityTest() throws Exception {
    System.out.println("//////-/////////");
    System.out.println(MockMvcRequestBuilders.get("/ListSpeciality"));
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("http://localhost:8200/ListSpeciality")
    .contentType(MediaType.APPLICATION_JSON)
    )
    .andExpect(MockMvcResultMatchers.status().isOk())
    .andReturn();

		}

}


